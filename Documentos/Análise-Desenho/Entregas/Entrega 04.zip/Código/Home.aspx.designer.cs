﻿//------------------------------------------------------------------------------
// <gerado automaticamente>
//     O código foi gerado por uma ferramenta.
//
//     As alterações ao arquivo poderão causar comportamento incorreto e serão perdidas se
//     o código é regenerado. 
// </gerado automaticamente>
//------------------------------------------------------------------------------

namespace CRMOnline {
    
    
    public partial class Home {
    }
}
