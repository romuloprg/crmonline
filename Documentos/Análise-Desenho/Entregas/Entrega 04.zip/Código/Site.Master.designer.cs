﻿//------------------------------------------------------------------------------
// <gerado automaticamente>
//     O código foi gerado por uma ferramenta.
//
//     As alterações ao arquivo poderão causar comportamento incorreto e serão perdidas se
//     o código é regenerado. 
// </gerado automaticamente>
//------------------------------------------------------------------------------

namespace CRMOnline {
    
    
    public partial class Site {
        
        /// <summary>
        /// Controle header.
        /// </summary>
        /// <remarks>
        /// Campo gerado automaticamente.
        /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ContentPlaceHolder header;
        
        /// <summary>
        /// Controle NavigationMenu.
        /// </summary>
        /// <remarks>
        /// Campo gerado automaticamente.
        /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Menu NavigationMenu;
        
        /// <summary>
        /// Controle body.
        /// </summary>
        /// <remarks>
        /// Campo gerado automaticamente.
        /// Modificar a declaração do campo de movimento do arquivo de designer para o arquivo code-behind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ContentPlaceHolder body;
    }
}
