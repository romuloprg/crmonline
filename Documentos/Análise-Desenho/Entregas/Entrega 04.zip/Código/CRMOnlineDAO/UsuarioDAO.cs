﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using CRMOnlineIDAO;
using CRMOnlineEntity;

namespace CRMOnlineDAO
{
    public class UsuarioDAO : IUsuarioDAO
    {
        private SqlConnection connection;

        public UsuarioDAO()
        {
            connection = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=CRMOnlineDB;Integrated Security=True");
        }

        public bool Inserir(UsuarioEntity usuario)
        {
            //TODO: Código para inserir Usuario
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_Inserir", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@cpfUsu", usuario.cpfUsu);
                command.Parameters.AddWithValue("@codGra", usuario.codGra);
                command.Parameters.AddWithValue("@nomUsu", usuario.nomUsu);
                command.Parameters.AddWithValue("@sexUsu", usuario.sexUsu);
                command.Parameters.AddWithValue("@endUsu", usuario.endUsu);
                command.Parameters.AddWithValue("@cidUsu", usuario.cidUsu);
                command.Parameters.AddWithValue("@ufUsu", usuario.ufUsu);
                command.Parameters.AddWithValue("@telUsu", usuario.telUsu);
                command.Parameters.AddWithValue("@emaUsu", usuario.emaUsu);
                command.Parameters.AddWithValue("@tipUsu", "F");
                command.Parameters.AddWithValue("@senUsu", usuario.senUsu);
                command.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool Atualizar(UsuarioEntity usuario)
        {
            //TODO: Código para atualizar usuário
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_Atualizar", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@cpfUsu", usuario.cpfUsu);
                command.Parameters.AddWithValue("@codGra", usuario.codGra);
                command.Parameters.AddWithValue("@nomUsu", usuario.nomUsu);
                command.Parameters.AddWithValue("@sexUsu", usuario.sexUsu);
                command.Parameters.AddWithValue("@endUsu", usuario.endUsu);
                command.Parameters.AddWithValue("@cidUsu", usuario.cidUsu);
                command.Parameters.AddWithValue("@ufUsu", usuario.ufUsu);
                command.Parameters.AddWithValue("@telUsu", usuario.telUsu);
                command.Parameters.AddWithValue("@emaUsu", usuario.emaUsu);
                command.Parameters.AddWithValue("@senUsu", usuario.senUsu);
                command.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool AtualizarPermissao(UsuarioEntity usuario)
        {
            //TODO: Código para atualizar usuário
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_AtualizarPermissao", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@cpfUsu", usuario.cpfUsu);
                command.Parameters.AddWithValue("@tipUsu", usuario.tipUsu);
                command.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool Remover(string cpfUsu)
        {
            //TODO: código para remover usuário
            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_Remover", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@cpfUsu", cpfUsu);
                command.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }

            return true;
        }

        private T ObterValor<T>(IDataReader reader, int indice, T valorDefault)
        {
            //TODO: código para selecionar valores dos registros
            if (!reader.IsDBNull(indice))
                return (T)reader.GetValue(indice);
            else
                return valorDefault;
        }

        public List<UsuarioEntity> ObterTodos()
        {
            //TODO: código para selecionar todos os usuarios
            List<UsuarioEntity> usuarios = new List<UsuarioEntity>();

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_ObterTodos", connection);
                command.CommandType = CommandType.StoredProcedure;
                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    UsuarioEntity usuario = new UsuarioEntity();

                    object valor = reader.GetValue(0);

                    usuario.cpfUsu = this.ObterValor<string>(reader, 0, null);
                    usuario.nomUsu = this.ObterValor<string>(reader, 1, null);
                    usuario.sexUsu = this.ObterValor<string>(reader, 2, null);
                    usuario.endUsu = this.ObterValor<string>(reader, 3, null);
                    usuario.cidUsu = this.ObterValor<string>(reader, 4, null);
                    usuario.ufUsu = this.ObterValor<string>(reader, 5, null);
                    usuario.telUsu = this.ObterValor<string>(reader, 6, null);
                    usuario.emaUsu = this.ObterValor<string>(reader, 7, null);
                    usuario.tipUsu = this.ObterValor<string>(reader, 8, null);
                    if (usuario.tipUsu == "F")
                        usuario.tipUsu = "Funcionário";
                    else if (usuario.tipUsu == "A")
                        usuario.tipUsu = "Administrador";
                    else if (usuario.tipUsu == "P")
                        usuario.tipUsu = "Proprietário";
                    usuario.senUsu = this.ObterValor<string>(reader, 9, null);
                    usuario.codGra = this.ObterValor<int>(reader, 10, 0);
                    usuario.nomGra = this.ObterValor<string>(reader, 11, null);

                    usuarios.Add(usuario);
                }
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }

            return usuarios;
        }

        public UsuarioEntity Obter(string cpfUsu)
        {
            //TODO: código para selecionar um usuário pelo cpf
            UsuarioEntity usuario = new UsuarioEntity();

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_Obter", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@cpfUsu", cpfUsu);
                IDataReader reader = command.ExecuteReader();

                reader.Read();
                object valor = reader.GetValue(0);

                usuario.cpfUsu = this.ObterValor<string>(reader, 0, null);
                usuario.nomUsu = this.ObterValor<string>(reader, 1, null);
                usuario.sexUsu = this.ObterValor<string>(reader, 2, null);
                usuario.endUsu = this.ObterValor<string>(reader, 3, null);
                usuario.cidUsu = this.ObterValor<string>(reader, 4, null);
                usuario.ufUsu = this.ObterValor<string>(reader, 5, null);
                usuario.telUsu = this.ObterValor<string>(reader, 6, null);
                usuario.emaUsu = this.ObterValor<string>(reader, 7, null);
                usuario.tipUsu = this.ObterValor<string>(reader, 8, null);
                if (usuario.tipUsu == "F")
                    usuario.tipUsu = "Funcionário";
                else if (usuario.tipUsu == "A")
                    usuario.tipUsu = "Administrador";
                else if (usuario.tipUsu == "P")
                    usuario.tipUsu = "Proprietário";
                usuario.senUsu = this.ObterValor<string>(reader, 9, null);
                usuario.codGra = this.ObterValor<int>(reader, 10, 0);
                usuario.nomGra = this.ObterValor<string>(reader, 11, null);
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }

            return usuario;
        }

        public List<UsuarioEntity> Buscar(string busca)
        {
            //TODO: código para selecionar usuários
            List<UsuarioEntity> usuarios = new List<UsuarioEntity>();

            try
            {
                connection.Open();
                SqlCommand command = new SqlCommand("usuario_Buscar", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@busca", busca);
                IDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    UsuarioEntity usuario = new UsuarioEntity();

                    object valor = reader.GetValue(0);

                    usuario.cpfUsu = this.ObterValor<string>(reader, 0, null);
                    usuario.nomUsu = this.ObterValor<string>(reader, 1, null);
                    usuario.sexUsu = this.ObterValor<string>(reader, 2, null);
                    usuario.endUsu = this.ObterValor<string>(reader, 3, null);
                    usuario.cidUsu = this.ObterValor<string>(reader, 4, null);
                    usuario.ufUsu = this.ObterValor<string>(reader, 5, null);
                    usuario.telUsu = this.ObterValor<string>(reader, 6, null);
                    usuario.emaUsu = this.ObterValor<string>(reader, 7, null);
                    usuario.tipUsu = this.ObterValor<string>(reader, 8, null);
                    if (usuario.tipUsu == "F")
                        usuario.tipUsu = "Funcionário";
                    else if (usuario.tipUsu == "A")
                        usuario.tipUsu = "Administrador";
                    else if (usuario.tipUsu == "P")
                        usuario.tipUsu = "Proprietário";
                    usuario.senUsu = this.ObterValor<string>(reader, 9, null);
                    usuario.codGra = this.ObterValor<int>(reader, 10, 0);
                    usuario.nomGra = this.ObterValor<string>(reader, 11, null);

                    usuarios.Add(usuario);
                }
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }

            return usuarios;
        }
    }
}
