﻿using System;
using System.Collections.Generic;
using CRMOnlineEntity;
using CRMOnlineIDAO;
using CRMOnlineController.Factory;

namespace CRMOnlineController
{
    public class UsuarioController
    {
        public bool Inserir(UsuarioEntity usuario)
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.Inserir(usuario);
        }

        public bool Atualizar(UsuarioEntity usuario)
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.Atualizar(usuario);
        }

        public bool AtualizarPermissao(UsuarioEntity usuario)
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.AtualizarPermissao(usuario);
        }

        public bool Remover(string cpfUsu)
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.Remover(cpfUsu);
        }

        public List<UsuarioEntity> ObterTodos()
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.ObterTodos();
        }

        public UsuarioEntity Obter(string cpfUsu)
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.Obter(cpfUsu);
        }

        public List<UsuarioEntity> Buscar(string busca)
        {
            IUsuarioDAO iUsuarioDAO = (IUsuarioDAO)DAOFactory.CreateDAO<IUsuarioDAO>();
            return iUsuarioDAO.Buscar(busca);
        }
    }
}
