﻿using System;

namespace CRMOnlineEntity
{
    public class GraduacaoEntity
    {
        public int codGra { get; set; }
        public string nomGra { get; set; }
    }
}
