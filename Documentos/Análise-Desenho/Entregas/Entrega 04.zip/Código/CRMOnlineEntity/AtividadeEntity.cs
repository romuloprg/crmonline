﻿using System;

namespace CRMOnlineEntity
{
    public class AtividadeEntity
    {
        public int codAti { get; set; }
        public string desAti { get; set; }
        public string tipAti { get; set; }
        public string datAti { get; set; }
        public string horAti { get; set; }
        public int durAti { get; set; }
    }
}
