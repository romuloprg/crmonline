﻿using System;

namespace CRMOnlineEntity
{
    public class UsuarioEntity
    {
        public string cpfUsu { get; set; }
        public string nomUsu { get; set; }
        public string endUsu { get; set; }
        public string ufUsu { get; set; }
        public string cidUsu { get; set; }
        public string sexUsu { get; set; }
        public string telUsu { get; set; }
        public string emaUsu { get; set; }
        public string tipUsu { get; set; }
        public string senUsu { get; set; }
        public int codGra { get; set; }
        public string nomGra { get; set; }
    }
}
