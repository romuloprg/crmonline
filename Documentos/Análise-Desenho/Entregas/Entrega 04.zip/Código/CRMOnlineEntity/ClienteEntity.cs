﻿using System;

namespace CRMOnlineEntity
{
    public class ClienteEntity
    {
        public int codCli { get; set; }
        public string nomCli { get; set; }
        public string endCli { get; set; }
        public string cidCli { get; set; }
        public string ufCli { get; set; }
        public string cnpjEmp { get; set; }
        public string nomEmp { get; set; }
    }
}
