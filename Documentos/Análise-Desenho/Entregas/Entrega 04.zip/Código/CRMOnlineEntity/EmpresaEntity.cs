﻿using System;

namespace CRMOnlineEntity
{
    public class EmpresaEntity
    {
        public string cnpjEmp { get; set; }
        public string razEmp { get; set; }
        public string nomEmp { get; set; }
        public string endEmp { get; set; }
        public string cidEmp { get; set; }
        public string ufEmp { get; set; }
        public string telEmp { get; set; }
    }
}
