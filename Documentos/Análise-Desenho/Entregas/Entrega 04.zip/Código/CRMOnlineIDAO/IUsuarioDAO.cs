﻿using System;
using System.Collections.Generic;
using CRMOnlineEntity;

namespace CRMOnlineIDAO
{
    public interface IUsuarioDAO
    {
        bool Inserir(UsuarioEntity usuario);
        bool Atualizar(UsuarioEntity usuario);
        bool AtualizarPermissao(UsuarioEntity usuario);
        bool Remover(string cpfUsu);
        List<UsuarioEntity> ObterTodos();
        UsuarioEntity Obter(string cpfUsu);
        List<UsuarioEntity> Buscar(string busca);
    }
}
