﻿using System;
using System.Collections.Generic;
using CRMOnlineEntity;

namespace CRMOnlineIDAO
{
    public interface IGraduacaoDAO
    {
        List<GraduacaoEntity> ObterTodos();
    }
}
